package com.example.lehenlanajontomas.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.lehenlanajontomas.R;

import java.util.List;

public class CharAdapter extends RecyclerView.Adapter<CharAdapter.viewHolder>{

    private List<Character> listaPersonajes;
    private int layout;

    public CharAdapter(List<Character> listaPersonajes, int layout) {
        this.listaPersonajes = listaPersonajes;
        this.layout = layout;
    }

    @NonNull
    @Override
    public viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) { // En este método se le asigna el layout del CardView que se ha creado
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.tarjeta_personaje, parent, false);
        return new viewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull viewHolder holder, int position) { // Aquí se asigna cada dato al layout del CardView
        holder.bind(listaPersonajes.get(position));
    }

    @Override
    public int getItemCount() {
        if (listaPersonajes != null) {
            return listaPersonajes.size();
        }
        else return 0;

    }

    public void setCharacter(List<Character> characterList) {  // Se recibe la lista de personajes
        this.listaPersonajes=characterList;
    }

    public static class viewHolder extends RecyclerView.ViewHolder {

        public TextView nombre;
        public TextView nacionalidad;
        public TextView trabajo;
        public TextView nivel;
        public TextView habilidades;

        public viewHolder(@NonNull View itemView) {
            super(itemView);
            nombre = itemView.findViewById(R.id.textNombre);
            nacionalidad = itemView.findViewById(R.id.textNacion);
            trabajo = itemView.findViewById(R.id.textTrabajo);
            nivel = itemView.findViewById(R.id.textNivel);
            habilidades = itemView.findViewById(R.id.textHabilidades);
        }

        public void bind(final Character character){
            nombre.setText(character.getNombre());
            nacionalidad.setText(character.getNacionalidad());
            trabajo.setText(character.getTrabajo());
            nivel.setText(character.getNivel());
            habilidades.setText(character.getHabilidades());
        }
    }
}
