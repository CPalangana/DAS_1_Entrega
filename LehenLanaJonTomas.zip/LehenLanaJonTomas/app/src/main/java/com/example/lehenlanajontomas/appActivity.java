package com.example.lehenlanajontomas;

import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.lehenlanajontomas.adapter.CharAdapter;
import com.example.lehenlanajontomas.adapter.Character;
import com.example.lehenlanajontomas.db.DbHelper;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class appActivity extends AppCompatActivity {

    RecyclerView charRecycler;          // Aqui inicializamos los datos que se usarán para guardar...
    CharAdapter charAdapter;            // los objetos de nuesto layout
    Button btn_añadirpersonaje;
    EditText editData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.app_layout);
        if (DbHelper.existeDB()){
            System.out.println("La base de datos ya existe por lo que no se generará de nuevo. ");
        }
        else {
            System.out.println("Se generará la base de datos por primera vez. ");
            DbHelper dbHelper = new DbHelper(appActivity.this);
            SQLiteDatabase db = dbHelper.getWritableDatabase();
            if (db != null){Toast.makeText(appActivity.this, "Base de datos creada.", Toast.LENGTH_LONG).show();}
            else{Toast.makeText(appActivity.this, "Error al crear la base de datos.", Toast.LENGTH_LONG).show();}
        }
        actualizarRecycler(); // Se llama al método para que los objetos de la tabla se visualicen en el RecyclerView
        btn_añadirpersonaje = (Button) findViewById(R.id.addChar);
        editData = (EditText) findViewById(R.id.textInputEditText);
        btn_añadirpersonaje.setOnClickListener(new View.OnClickListener() { // Aquí le damos la funcionalidad al botón Añadir...
            @Override                                                       // que al pulsarse pasará los datos del editText al método
            public void onClick(View view) {                                // que introduce los datos a la tabla de la db
                String input;                                               // y posteriormente actualiza el RecyclerView para que el nuevo dato se muestre
                input = editData.getText().toString();
                addChar(input);
                actualizarRecycler();
            }
        });
    }

    private void actualizarRecycler() {
        DbHelper dbHelper = new DbHelper(appActivity.this);
        charRecycler = findViewById(R.id.charRecyclerView);
        charRecycler.setLayoutManager(new LinearLayoutManager(this));
        ArrayList<ArrayList<String>> listaPersonajes;
        listaPersonajes = dbHelper.readTable();
        List<Character> CharacterList = new List<Character>() {
            @Override
            public int size() {return 0;}
            @Override
            public boolean isEmpty() {return false;}
            @Override
            public boolean contains(@Nullable Object o) {return false;}
            @NonNull
            @Override
            public Iterator<Character> iterator() {return null;}
            @NonNull
            @Override
            public Object[] toArray() {return new Object[0];}
            @NonNull
            @Override
            public <T> T[] toArray(@NonNull T[] ts) {return null;}
            @Override
            public boolean add(Character character) {return false;}
            @Override
            public boolean remove(@Nullable Object o) {return false;}
            @Override
            public boolean containsAll(@NonNull Collection<?> collection) {return false;}
            @Override
            public boolean addAll(@NonNull Collection<? extends Character> collection) {return false;}
            @Override
            public boolean addAll(int i, @NonNull Collection<? extends Character> collection) {return false;}
            @Override
            public boolean removeAll(@NonNull Collection<?> collection) {return false;}
            @Override
            public boolean retainAll(@NonNull Collection<?> collection) {return false;}
            @Override
            public void clear() {}
            @Override
            public Character get(int i) {return null;}
            @Override
            public Character set(int i, Character character) {return null;}
            @Override
            public void add(int i, Character character) {}
            @Override
            public Character remove(int i) {return null;}
            @Override
            public int indexOf(@Nullable Object o) {return 0;}
            @Override
            public int lastIndexOf(@Nullable Object o) {return 0;}
            @NonNull
            @Override
            public ListIterator<Character> listIterator() {return null;}
            @NonNull
            @Override
            public ListIterator<Character> listIterator(int i) {return null;}
            @NonNull
            @Override
            public List<Character> subList(int i, int i1) {return null;}
        };
        if(listaPersonajes.size() > 0) { // Si hay algun elemento
            for(int i = 0; i < listaPersonajes.size(); i++){  // Recorremos los elementos
                Character personaje = new Character("Pepe"); // Es una inicialización necesaria que ser reescribirá
                personaje.setNombre(listaPersonajes.get(i).get(0));  // Se guarda el nombre de cada personaje y así con el resto de datos
                personaje.setNacionalidad(listaPersonajes.get(i).get(1));
                personaje.setTrabajo(listaPersonajes.get(i).get(2));
                personaje.setNivel(Integer.parseInt(listaPersonajes.get(i).get(3)));
                personaje.setHabilidades(listaPersonajes.get(i).get(4));
                CharacterList.add(personaje); // Se añade el personaje a la lista de personajes
            }
        }
        Character personaje = new Character("Pepe","Algeciras","Fontanero",4,"Arreglar tuberías"); // Aquí se introduce un personaje de prueba, para que no esté vacío
        CharacterList.add(personaje);
        if(charAdapter == null){  // Si es la primera vez
            charAdapter = new CharAdapter(CharacterList,R.layout.tarjeta_personaje); // Se establece la lista para el adaptador
            charRecycler.setAdapter(charAdapter); // Y se le asigna el adaptador al RecyclerView
            charRecycler.setItemAnimator(new DefaultItemAnimator());
        }
        else{ // Al actualizar
            charRecycler.setAdapter(charAdapter);
            charAdapter.setCharacter(CharacterList); // Se actualiza la lista en el adaptador
            charAdapter.notifyDataSetChanged(); // Y se notifica para que se actualice el RecycleView
            charRecycler.setItemAnimator(new DefaultItemAnimator());
        }
    }

    /*public void actualizarLista(){
        DbHelper dbHelper = new DbHelper(appActivity.this);
        ArrayList<ArrayList<String>> listaPersonajes;
        listaPersonajes = dbHelper.readTable();
        charListView.setBackgroundColor(Color.DKGRAY);
        if(listaPersonajes.size() > 0) { // Si hay algun elemento
            ArrayList<String> item = listaPersonajes.get(0); // Metemos el primer personaje
            ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, item);
            charListView.setAdapter(adapter);
            for (int i = 1; i < listaPersonajes.size(); i++) { // Y recorriendo el resto de la lista
                item = listaPersonajes.get(i);
                adapter.add(item);                             // introducimos el resto
                adapter.notifyDataSetChanged();                // y actualizamos el adaptador
            }
        }
    }*/

    public void addChar(String datos){ // Este método recoge el string completo del input
        if (datos != null){
            String[] listaDatos = datos.split(","); // Se separa por cada coma
            if(listaDatos.length == 5) { // Si el número de elementos es el correcto
                añadirPersonaje(listaDatos[0], listaDatos[1], listaDatos[2], listaDatos[3], listaDatos[4]); // Se pasa al método que los introducirá en la tabla
            }
            else{Toast.makeText(appActivity.this, "Input incorrecto, compruebe el formato", Toast.LENGTH_LONG).show();}
        }
        else{
            Toast.makeText(appActivity.this, "Error al leer los datos de entrada", Toast.LENGTH_LONG).show();
        }
    }

    public void añadirPersonaje(String nombre, String nacionalidad, String trabajo, String nivel, String habilidades){
        DbHelper dbHelper = new DbHelper(appActivity.this);
        Boolean works = dbHelper.insertData(nombre, nacionalidad, trabajo, nivel, habilidades); // Se introducen los datos y se recoge la respuesta
        if(works){Toast.makeText(appActivity.this, "Personaje añadido", Toast.LENGTH_LONG).show();} // Respuesta = TRUE se introdujeron con éxito
        else{ Toast.makeText(appActivity.this, "Error al añadir personaje", Toast.LENGTH_LONG).show();} // Respuesta = FALSE error al introducir los datos
    }
}
