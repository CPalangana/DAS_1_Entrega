package com.example.lehenlanajontomas.adapter;

import androidx.annotation.NonNull;

public class Character {
    private String nombre;
    private String nacionalidad;
    private String trabajo;
    private int nivel;
    private String habilidades;

    public Character(String nombre, String nacionalidad, String trabajo, int nivel, String habilidades) {
        this.nombre = nombre;
        this.nacionalidad = nacionalidad;
        this.trabajo = trabajo;
        this.nivel = nivel;
        this.habilidades = habilidades;
    }

    public Character(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre(){return nombre;}

    public void setNombre(String name){this.nombre=name;}

    public String getNacionalidad(){return nacionalidad;}

    public void setNacionalidad(String nation){this.nacionalidad=nation;}

    public String getTrabajo(){return trabajo;}

    public void setTrabajo(String work){this.trabajo=work;}

    public int getNivel(){return nivel;}

    public void setNivel(int level){this.nivel=level;}

    public String getHabilidades(){return habilidades;}

    public void setHabilidades(String skills){this.habilidades=skills;}
}
