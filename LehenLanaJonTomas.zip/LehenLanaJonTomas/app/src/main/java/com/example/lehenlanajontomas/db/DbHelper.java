package com.example.lehenlanajontomas.db;

import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class DbHelper extends SQLiteOpenHelper {
    public static Boolean dbExiste = FALSE; // Comprobatorio de si la base de datos ya está creada
    private static final int DATABASE_VERSION = 1;              // <-.
    private static final String DATABASE_NOMBRE = "info.db";    // <- Información para la base de datos
    public static final String TABLE_FICHAS = "t_fichas";       // <-·


    public DbHelper(@Nullable Context context) {
        super(context, DATABASE_NOMBRE, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        if (!dbExiste) {
            sqLiteDatabase.execSQL("CREATE TABLE " + TABLE_FICHAS + "(" + // Si la Tabla t_fichas no existe al abrir la actividad, se creará
                    "nombre TEXT PRIMARY KEY," +
                    "nacionalidad TEXT," +
                    "trabajo TEXT," +
                    "nivel INTEGER," +
                    "habilidades TEXT);");
        }
        dbExiste = TRUE;  // Se marcará como que ya existe
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE " + TABLE_FICHAS);
        onCreate(sqLiteDatabase);
    }

    @Override
    public synchronized void close() {
        super.close();
    }

    public static Boolean existeDB(){
       return dbExiste;
    } // Para comprobarlo desde otra actividad

    public boolean insertData(String Nombre, String Nacionalidad, String Trabajo, String Nivel, String Habilidades){
                                // El método se encarga de meter los datos que los usuarios quieran guardar al recibirlos de la entrada.
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("nombre", Nombre);
        contentValues.put("nacionalidad", Nacionalidad);
        contentValues.put("trabajo", Trabajo);
        contentValues.put("nivel", Nivel);
        contentValues.put("habilidades", Habilidades);
        long result = db.insert(TABLE_FICHAS,null,contentValues); // Aquí se insertan los datos en la base de datos
        if(result == -1) // Si se produce un error devolverá FALSE
            return FALSE;
        else // Si no hay errores se dará por hecho que los datos se han introducido correctamente
            return TRUE;
    }


    @SuppressLint("Range")
    public ArrayList<ArrayList<String>> readTable(){  // El método recoge los datos de la tabla t_fichas de la base de datos y los devuelve como una lista de personajes...
        SQLiteDatabase db = this.getWritableDatabase(); // en la que cada elemento es una lista de Strings, siendo cada uno de ellos un dato de un personaje.
        ArrayList<String> listaLinea = new ArrayList<String>();
        ArrayList<ArrayList<String>> listaDatos = new ArrayList<ArrayList<String>>();
        if(dbExiste) {
            Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_FICHAS, null); // Aquí se hace la lectura
            if (cursor != null) { // Si encontramos algo en la tabla
                cursor.moveToFirst();
                int i = 0;
                while (cursor.moveToNext()) { // Recorremos los datos recibidos
                    listaLinea.set(0, cursor.getString(cursor.getColumnIndex("nombre")));                // el nombre
                    listaLinea.set(1, cursor.getString(cursor.getColumnIndex("nacionalidad")));          // la nacionalidad
                    listaLinea.set(2, cursor.getString(cursor.getColumnIndex("trabajo")));               // el trabajo
                    listaLinea.set(3, (String.valueOf(cursor.getInt(cursor.getColumnIndex("nivel")))));  // el nivel (Que es un int, pero pasaremos como String para que todos los datos sean del mismo tipo)
                    listaLinea.set(4, cursor.getString(cursor.getColumnIndex("habilidades")));           // las habilidades
                    listaDatos.set(i, listaLinea);         // Aquí se introduce la lista del personaje a la lista de personajes
                    i++;
                }
                cursor.close();
                return listaDatos;
            }
            else {System.out.println("NO SE HA ENCONTRADO NADA EN LA BASE DE DATOS");
                return new ArrayList<ArrayList<String>>(); // Si no hay nada en la tabla devolvemos una lista vacía
            }
        }
        else return new ArrayList<ArrayList<String>>(); // Si la tabla no ha sido creada aun devolvemos una lista vacía
    }
}
