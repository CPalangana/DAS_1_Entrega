package com.example.lehenlanajontomas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_layout);
    }
    public void goToMain(View view) { // Pulsar el botón Atrás nos llevará de vuelta a MainActivity
        Button registeraccept = (Button) view;
        Intent myIntent = new Intent(RegisterActivity.this, MainActivity.class);
        RegisterActivity.this.startActivity(myIntent);
    }

    public void goregister(View view) { // Pulsar el botón Aceptar guardará las nuevas credenciales* si son correctas y nos llevará de vuelta a MainActivity
        Button registeraccept = (Button) view;
        EditText registername;
        TextView registerpwd;
        registername = (EditText) findViewById(R.id.registertext);
        registerpwd = (TextView) findViewById(R.id.regpassword);
        if(registername.getText()==null){
            Toast.makeText(RegisterActivity.this, "Error con el usuario", Toast.LENGTH_LONG).show();
        }
        else{
            if(registerpwd.getText()==null){Toast.makeText(RegisterActivity.this, "Error con la contraseña", Toast.LENGTH_LONG).show();}
            else {
                Intent myIntent = new Intent(RegisterActivity.this, MainActivity.class);
                RegisterActivity.this.startActivity(myIntent);
            }
        }
    }
}
