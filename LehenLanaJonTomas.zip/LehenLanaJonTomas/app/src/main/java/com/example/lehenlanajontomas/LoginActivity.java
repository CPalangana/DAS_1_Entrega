package com.example.lehenlanajontomas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_layout);
    }
    public void goToMain(View view) { // Pulsar el botón Atrás nos llevará de vuelta a MainActivity
        Button loginboton = (Button) view;
        Intent myIntent = new Intent(LoginActivity.this, MainActivity.class);
        LoginActivity.this.startActivity(myIntent);
    }

    public void goAppActivity(View view) { // Pulsar el botón Aceptar comprobará las credenciales* y nos llevará a appActivity si son correctas
        Button loginboton = (Button) view;
        EditText loginname;
        TextView loginpwd;
        loginname = (EditText) findViewById(R.id.logintext);
        loginpwd = (TextView) findViewById(R.id.password);
        if(loginname.getText()==null){
            Toast.makeText(LoginActivity.this, "Error con el usuario", Toast.LENGTH_LONG).show();
        }
        else{
            if(loginpwd.getText()==null){Toast.makeText(LoginActivity.this, "Error con la contraseña", Toast.LENGTH_LONG).show();}
            else {
                Intent myIntent = new Intent(LoginActivity.this, appActivity.class);
                LoginActivity.this.startActivity(myIntent);
            }
        }
    }

}
